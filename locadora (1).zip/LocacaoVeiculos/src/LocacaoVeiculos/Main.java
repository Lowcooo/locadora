package LocacaoVeiculos;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Veiculo vec;
        Locadora loc=new Locadora();
        Scanner teclado = new Scanner(System.in);
        String placa, tipo;
        boolean statusLocado;
        float valorDia;
        
        int op;   
        
        do {
            System.out.println("Digite a opcao: ");
            op=teclado.nextInt();

            switch (op) {
            
            	case 1:
                	System.out.println("Digite a Placa...:***\n");
                    placa = teclado.next();
                    System.out.print("Digite o tipo......: ");
                    tipo = teclado.next();
                    System.out.print("Digite o valor de diaria .: ");
                    valorDia = teclado.nextFloat();
                    statusLocado = true;
                    vec = new Veiculo(placa, tipo, valorDia, statusLocado);
                    loc.cadastrarVeiculo(vec);
                    break;
                case 2:
                    System.out.println("\n\n*** MOSTRAR ***\n");
                    for (Veiculo v: loc.getVeiculos()) {
                        System.out.println("Placa: " + v.getPlaca()+ "| Tipo: "+ v.getTipo()+"| Valor: "+v.getValorDia()+"| Status: ");
                    }
            }
        } while (op != 3);
    }

}
