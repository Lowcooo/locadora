
package LocacaoVeiculos;

public class Veiculo {
   private String placa;
   private String tipo;
   private float valorDia;
   private boolean statusLocado;

    public Veiculo(String placa, String tipo, float valorDia, boolean statusLocado) {
        this.placa = placa;
        this.tipo = tipo;
        this.valorDia = valorDia;
        this.statusLocado = statusLocado;
    }

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public float getValorDia() {
		return valorDia;
	}

	public void setValorDia(float valorDia) {
		this.valorDia = valorDia;
	}

	public boolean isStatusLocado() {
		return statusLocado;
	}

	public void setStatusLocado(boolean statusLocado) {
		this.statusLocado = statusLocado;
	}
}
