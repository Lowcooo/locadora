package LocacaoVeiculos;

import java.util.ArrayList;
import java.util.List;

public class Locadora {

    private List<Veiculo> veiculos;
    private List<Funcionario> funcionarios;
    private List<Cliente> clientes;
    private List<Locacao> locacaos;

    public Locadora() {
        this.veiculos = new ArrayList<Veiculo>();
        this.funcionarios = new ArrayList<Funcionario>();
        this.clientes = new ArrayList<Cliente>();
        this.locacaos = new ArrayList<Locacao>();
    }

    public void cadastrarVeiculo(Veiculo veiculo) {
        this.veiculos.add(veiculo);
    }

    public Veiculo consultarVeiculo(String placa) {
        for (Veiculo v : this.veiculos) {
            if (v.getPlaca().equals(placa)) {
                return v;
            }
        }
        return null;
    }
    
    public List<Veiculo> getVeiculos() {
        return veiculos;

    }

    public void setVeiculos(List<Veiculo> veiculos) {
        this.veiculos = veiculos;
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    public List<Locacao> getLocacaos() {
        return locacaos;
    }

    public void setLocacaos(List<Locacao> locacaos) {
        this.locacaos = locacaos;
    }

}
