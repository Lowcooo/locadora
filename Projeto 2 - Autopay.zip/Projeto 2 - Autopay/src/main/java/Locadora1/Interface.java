package Locadora1;

import java.util.ArrayList;

public interface Interface {

     String listarCarros(ArrayList<Carro> carros); //ASSINATURA DE listarCarros
}
